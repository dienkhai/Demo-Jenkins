const var key_colors = {
    light_blue:0x329cff,
    red:0xff3939,
    yellow:0xfff538,
    green:0x37ff45,
    pink:0xf136ff
};
