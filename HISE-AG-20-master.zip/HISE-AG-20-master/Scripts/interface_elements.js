// ui elements 
const var Interface = {
    Release_Knob : Content.getComponent("Release Knob"),
    Power_Slap : Content.getComponent("Power Slap"),
    Harmonics : Content.getComponent("Harmonics"),
    Soft_velocity : Content.getComponent("Soft Velocity"),
    Predictive_Playback : Content.getComponent("PP button"),
    Neighbour_RR : Content.getComponent("Neighbour RR"),
    Release_Samples_Button : Content.getComponent("Release Samples Button"),
    Fake_12str : Content.getComponent("12 Str Volume"),
};